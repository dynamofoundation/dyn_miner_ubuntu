#pragma once

extern bool globalFound;
extern bool globalTimeout;
extern uint32_t globalNonceCount;